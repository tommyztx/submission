import click
from attorney.commands import manage, validate
from attorney.git import git_repo_check


@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx):
    """Attorney: A CLI tool for managing project submissions"""
    # Check if we're in a git repo and at its root before proceeding
    git_repo_check()

    if ctx.invoked_subcommand is None:
        ctx.invoke(manage.manage)

cli.add_command(validate.validate)

if __name__ == "__main__":
    cli()
