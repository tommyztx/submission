from pathlib import Path
from typing import List, Dict, Optional
import shutil
import click
import inquirer


class TemplateManager:
    def __init__(self):
        self.template_dir = Path(__file__).parent / 'templates'

    def get_available_templates(self) -> List[str]:
        """Get list of available template languages"""
        if not self.template_dir.exists():
            click.echo("✗ Template directory not found. Please reinstall attorney.")
            return []
        return [d.name for d in self.template_dir.iterdir() if d.is_dir()]


    def copy_template(self, language: str, destination: Path) -> bool:
        """Copy template files to destination directory"""
        template_path = self.template_dir / language
        if not template_path.exists():
            click.echo(f"✗ Template '{language}' not found")
            return False

        # Ensure destination directory exists
        destination.mkdir(parents=True, exist_ok=True)

        try:
            # Copy all files and directories recursively
            for template_item in template_path.glob('**/*'):
                # Get the relative path from the template root
                relative_path = template_item.relative_to(template_path)
                dest_item = destination / relative_path

                if template_item.is_dir():
                    # Create directory if it doesn't exist
                    dest_item.mkdir(parents=True, exist_ok=True)
                else:
                    # Create parent directories if they don't exist
                    dest_item.parent.mkdir(parents=True, exist_ok=True)
                    # Only copy if destination doesn't exist
                    if not dest_item.exists():
                        shutil.copy2(template_item, dest_item)
            return True
        except Exception as e:
            click.echo(f"✗ Error copying template files: {str(e)}")
            return False

def prompt_for_dockerfile(submission_path: Path) -> bool:
    """
    Prompt user to add a Dockerfile if one doesn't exist.
    Returns True if a template was applied.
    """
    if (submission_path / "Dockerfile").exists():
        return False

    questions = [
        inquirer.Confirm(
            'add_dockerfile',
            message="No Dockerfile found. Would you like to add one?",
            default=True
        ),
    ]

    answers = inquirer.prompt(questions)
    if not answers or not answers['add_dockerfile']:
        return False

    template_mgr = TemplateManager()
    templates = template_mgr.get_available_templates()

    if not templates:
        return False

    template_question = [
        inquirer.List(
            'template',
            message="Select a template",
            choices=templates,
        ),
    ]

    template_answer = inquirer.prompt(template_question)
    if not template_answer:
        return False

    selected_template = template_answer['template']
    if template_mgr.copy_template(selected_template, submission_path):
        click.echo(f"✓ Applied {selected_template} template to {submission_path}")
        return True
    else:
        click.echo("✗ Failed to apply template")
        return False
