import subprocess
from pathlib import Path
import click
import os
import shutil


def get_git_root():
    """Get the root directory of the git repository"""
    try:
        root_dir = subprocess.check_output(
            ['git', 'rev-parse', '--show-toplevel'],
            stderr=subprocess.STDOUT
        ).decode('utf-8').strip()
        return Path(root_dir).resolve()
    except subprocess.CalledProcessError:
        return None


def git_repo_check():
    """Ensure we're in a git repository and at its root"""
    if not is_git_repo():
        click.echo("✗ Error: attorney must be run within a git repository")
        click.echo("   Please initialize a git repository first with 'git init'")
        raise click.Abort()

    current_dir = Path.cwd().resolve()
    git_root = get_git_root()

    if current_dir != git_root:
        click.echo("✗ Error: attorney must be run from the root of the git repository")
        click.echo(f"   Please change to: {git_root}")
        raise click.Abort()


def get_git_dir():
    """Get the path to the .git directory"""
    try:
        git_dir = subprocess.check_output(
            ['git', 'rev-parse', '--git-dir'],
            stderr=subprocess.STDOUT
        ).decode('utf-8').strip()
        return Path(git_dir).resolve()
    except subprocess.CalledProcessError:
        return None


def is_git_repo():
    """Check if current directory is in a git repository"""
    return get_git_dir() is not None


def setup_git_hooks():
    """Setup git hooks for attorney validation"""
    git_dir = get_git_dir()
    if not git_dir:
        click.echo("Could not find .git directory. Skipping git hook setup.")
        return False

    hooks_dir = git_dir / 'hooks'
    if not hooks_dir.exists():
        click.echo("Could not find hooks directory. Skipping git hook setup.")
        return False

    # Always use the shell script version
    hook_source = Path(__file__).parent / 'commands' / 'hooks' / 'pre-push.sh'
    hook_dest = hooks_dir / 'pre-push'

    try:
        # Copy the hook file
        shutil.copy2(hook_source, hook_dest)

        # Make the hook executable (important for both Windows Git Bash and Unix)
        hook_dest.chmod(hook_dest.stat().st_mode | 0o111)

        click.echo("✓ Git pre-push hook installed successfully!")
        return True
    except Exception as e:
        click.echo(f"Error setting up git hook: {str(e)}")
        return False
