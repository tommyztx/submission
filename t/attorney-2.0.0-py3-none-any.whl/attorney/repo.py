import shutil
from pathlib import Path
import click
from importlib import resources
import tempfile


class RepoManager:
    def setup_repo_files(self) -> bool:
        """Setup repository-level files and directories"""
        try:
            # Create a temporary directory to extract files
            with tempfile.TemporaryDirectory() as temp_dir:
                temp_path = Path(temp_dir)

                # Extract .github directory to temp location
                # Using importlib.resources to access package data
                with resources.path('attorney.repo_templates', '.github') as github_source:
                    github_dest = Path.cwd() / '.github'

                    # Copy to temporary location first
                    temp_github = temp_path / '.github'
                    shutil.copytree(github_source, temp_github)

                    # Then copy from temp to final destination
                    if not github_dest.exists():
                        shutil.copytree(temp_github, github_dest)
                        click.echo("✓ Created .github directory")

            return True
        except Exception as e:
            click.echo(f"✗ Error setting up repository files: {str(e)}")
            return False


def validate_repo_structure() -> bool:
    """Validate repository-level files and directories exist"""
    github_dir = Path.cwd() / '.github'

    if not github_dir.exists():
        click.echo(
            "\n[!] Missing .github directory in repository root:"
            "\n   Please run 'attorney' to set up repository files"
        )
        return False

    return True
