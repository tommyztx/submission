from typing import List
from pydantic import BaseModel, EmailStr

class Challenge(BaseModel):
    name: str
    submissions: List[str]

class Config(BaseModel):
    email: EmailStr
    challenges: List[Challenge]
