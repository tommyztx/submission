from pathlib import Path
import click


def validate_relative_path(ctx, param, value):
    """Validate that the path is relative and doesn't escape the project directory"""
    if value is None:
        return None

    path = Path(value)

    try:
        # Convert to absolute path to check for directory traversal
        abs_path = (Path.cwd() / path).resolve()
        # Check if this path would escape the current directory
        if not abs_path.is_relative_to(Path.cwd()):
            raise click.BadParameter("Path must not escape the project directory")
        return path
    except Exception:
        raise click.BadParameter("Invalid path")


def prompt_for_submission_path(prompt_text: str = "Enter folder for submission") -> Path:
    """Prompt for a submission path and validate it"""
    while True:
        try:
            path_str = click.prompt(prompt_text)
            # Use the same validation as the CLI
            path = validate_relative_path(None, None, path_str)
            return path
        except click.BadParameter as e:
            click.echo(f"✗ {str(e)}")