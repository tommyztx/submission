#!/bin/sh
# Attorney validation pre-push hook

# Get the git root directory
root_dir=$(git rev-parse --show-toplevel)

# Change to the root directory
cd "$root_dir" || exit 1

echo "Running attorney validation..."

# Run attorney validate (works in both Git Bash and Unix)
attorney validate
exit_code=$?

if [ $exit_code -ne 0 ]; then
    echo "✗ Attorney validation failed. Push aborted."
    echo "   Please fix the issues and try again."
    exit 1
fi

# Only reach here if validation succeeded
exit 0
