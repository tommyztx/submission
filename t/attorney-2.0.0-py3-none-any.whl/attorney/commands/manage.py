import click
import inquirer
import yaml
from pathlib import Path

from attorney.repo import RepoManager
from attorney.schema import Config
from attorney.data import get_available_challenges
from attorney.templates import prompt_for_dockerfile
from attorney.utils import prompt_for_submission_path
from attorney.git import setup_git_hooks

def load_or_create_config():
    """Load existing config or create new one with email"""
    first_run = not Path("config.yaml").exists()

    if first_run:
        # Setup repository files first
        repo_manager = RepoManager()
        repo_manager.setup_repo_files()

        questions = [
            inquirer.Text('email',
                          message="First, please enter your email address",
                          validate=lambda _, x: '@' in x)
        ]
        answers = inquirer.prompt(questions)
        config = {
            "email": answers['email'],
            "challenges": []
        }

        # Prompt for git hook setup
        setup_hook = inquirer.prompt([
            inquirer.Confirm('setup',
                             message="Would you like to set up git hooks to validate your configuration before "
                                     "pushing? (HIGHLY RECOMMENDED)",
                             default=True)
        ])

        if setup_hook['setup']:
            setup_git_hooks()

    else:
        with open("config.yaml") as f:
            config = yaml.safe_load(f)

    return config

def add_new_challenge(config, available_challenges, existing_challenges):
    """Add a new challenge to the config"""
    # Filter out challenges that are already in the config
    new_challenges = [c for c in available_challenges if c not in existing_challenges]

    if not new_challenges:
        click.echo("All available challenges have already been added! ❌")
        return False

    # Select challenge
    challenge_question = [
        inquirer.List('name',
                      message="Select the challenge to add:",
                      choices=new_challenges)
    ]
    challenge_answer = inquirer.prompt(challenge_question)

    # Get submission path
    submission_path = prompt_for_submission_path()
    if submission_path is None:
        return False

    # Create directory if it doesn't exist
    if not submission_path.exists():
        if not click.confirm(f"Directory '{submission_path}' does not exist. Create it?"):
            return False
        submission_path.mkdir(parents=True)
        click.echo(f"✓ Created directory: {submission_path}")

    prompt_for_dockerfile(submission_path)

    # Add to config, ensuring submissions is a list
    config["challenges"].append({
        "name": challenge_answer["name"],
        "submissions": [str(submission_path)] if submission_path else []
    })
    return True

def add_submission_to_existing(config, existing_challenges):
    """Add a new submission to an existing challenge"""
    if not existing_challenges:
        click.echo("No existing challenges found! ❌")
        return False

    # Select challenge
    challenge_question = [
        inquirer.List('challenge',
                      message="Select the challenge to add a submission to:",
                      choices=existing_challenges)
    ]
    challenge_answer = inquirer.prompt(challenge_question)

    # Get submission path
    submission_path = prompt_for_submission_path()
    if submission_path is None:
        return False

    # Create directory if it doesn't exist
    if not submission_path.exists():
        if not click.confirm(f"Directory '{submission_path}' does not exist. Create it?"):
            return False
        submission_path.mkdir(parents=True)
        click.echo(f"✓ Created directory: {submission_path}")

    prompt_for_dockerfile(submission_path)

    # Add to config
    for challenge in config["challenges"]:
        if challenge["name"] == challenge_answer["challenge"]:
            # Initialize submissions list if it doesn't exist or is None
            if not challenge.get("submissions"):
                challenge["submissions"] = []
            challenge["submissions"].append(str(submission_path))
            break

    return True


@click.command()
def manage():
    """Manage challenges and submissions"""
    config = load_or_create_config()

    while True:
        existing_challenges = [c["name"] for c in config["challenges"]]
        available_challenges = get_available_challenges()

        # Prepare menu choices
        choices = ["Add new challenge"]
        if existing_challenges:
            choices.append("Add submission to existing challenge")
        choices.append("Save and exit")

        action_question = [
            inquirer.List('action',
                          message="What would you like to do?",
                          choices=choices)
        ]

        action = inquirer.prompt(action_question)["action"]

        if action == "Add new challenge":
            success = add_new_challenge(config, available_challenges, existing_challenges)
        elif action == "Add submission to existing challenge":
            success = add_submission_to_existing(config, existing_challenges)
        else:  # Save and exit
            break

        if success:
            # Validate and save after each successful action
            try:
                validated_config = Config(**config)
                with open("config.yaml", "w") as f:
                    yaml.dump(config, f)
                click.echo("Configuration saved successfully! ✅")
            except Exception as e:
                click.echo(f"Error saving configuration: {str(e)} ❌")
                break
