import click
import yaml
import sys
from pathlib import Path

from attorney.repo import validate_repo_structure
from attorney.schema import Config


@click.command()
def validate():
    """Validate the configuration and submission paths"""
    has_errors = False

    # Validate repository structure
    if not validate_repo_structure():
        click.echo("[!] GitHub Action Missing in current directory")
        sys.exit(1)

    if not Path("config.yaml").exists():
        click.echo("[!] No config.yaml found in current directory")
        sys.exit(1)

    try:
        with open("config.yaml") as f:
            config_dict = yaml.safe_load(f)
    except yaml.YAMLError as e:
        click.echo(f"[!] Error reading config.yaml: {str(e)}")
        sys.exit(1)

    # First validate the config structure
    try:
        config = Config(**config_dict)
    except Exception as e:
        click.echo(f"[!] Invalid config structure: {str(e)}")
        sys.exit(1)

    has_errors = False

    # Validate paths and Dockerfiles exist
    for challenge in config.challenges:
        if not challenge.submissions:
            has_errors = True
            click.echo(
                f"\n[!] No submissions found for challenge '{challenge.name}':"
                f"\n   Please run 'attorney' to add submission folders"
            )
            continue

        for submission in challenge.submissions:
            submission_path = Path(submission)
            full_path = Path.cwd() / submission_path
            dockerfile_path = full_path / "Dockerfile"

            # Check if submission directory exists
            if not full_path.exists():
                has_errors = True
                click.echo(
                    f"\n[!] Missing directory for challenge '{challenge.name}':"
                    f"\n   Submission path: {submission}"
                    f"\n   Options:"
                    f"\n   1. Remove this entry from config.yaml if you no longer need it"
                    f"\n   2. Update the path in config.yaml if you renamed/moved the folder"
                )
                continue

            # Check if Dockerfile exists
            if not dockerfile_path.exists():
                has_errors = True
                click.echo(
                    f"\n[!] Missing Dockerfile for challenge '{challenge.name}':"
                    f"\n   Submission path: {submission}"
                    f"\n   Please add a Dockerfile to the submission directory"
                    f"\n   You can run 'attorney' to add a template Dockerfile"
                )

    if not has_errors:
        click.echo("[+] All paths and Dockerfiles in config.yaml are valid")
        sys.exit(0)

    sys.exit(1)
