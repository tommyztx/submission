from typing import List
import requests
import click


def get_available_challenges() -> List[str]:
    """
    Get list of available challenges from the API endpoint.
    Falls back to empty list if the request fails.
    """
    try:
        # Replace this URL with your actual endpoint
        response = requests.get("https://getchallenges-ryd3bo7wyq-uc.a.run.app")
        response.raise_for_status()  # Raises an HTTPError for bad responses

        data = response.json()
        return data.get("challenges", [])

    except requests.RequestException as e:
        click.echo(f"✗ Failed to fetch challenges: {str(e)}")
        return []
